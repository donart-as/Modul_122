# Projekt: System-Monitoring & Alarm bei Überlastung

## Tag 1 27.06.2025

Am ersten Tag des Projekts haben wir zunächst nach Projektideen gesucht und uns schließlich für das System-Monitoring mit Alarmierung entschieden. Zudem erstellten wir eine Anforderungsliste und generierten ein UML-Diagramm, das noch geändert werden sollte.

## Tag 2 04.07.2024

Wir haben uns heute mit unserem Code befasst und dabei sichergestellt, dass er per Cronjob automatisch läuft und im Alarmfall eine E-Mail an uns gesendet wird. Dazu haben wir einen MSMTP-Server erstellt. Über diesen sollen die Informationen an unsere E-Mail-Adresse gesendet werden.